#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/wait.h>

struct account_info {
    char user_option[100];
    int account_balance;
};

int main() {
    pid_t child_process;
    int pipe_fd[2];
    char pipe_buffer[200];

    if (pipe(pipe_fd) == -1) {
        perror("pipe creation failed");
        exit(1);
    }

    int shared_mem_id = shmget((key_t)202, sizeof(struct account_info), 0666 | IPC_CREAT);
    if (shared_mem_id == -1) {
        perror("shared memory allocation failed");
        exit(1);
    }

    struct account_info *shared_data = (struct account_info *)shmat(shared_mem_id, NULL, 0);
    if (shared_data == (void *)-1) {
        perror("shared memory attachment failed");
        exit(1);
    }

    shared_data->account_balance = 1000;

    printf("Please choose an option:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n");

    read(0, shared_data->user_option, sizeof(shared_data->user_option));
    shared_data->user_option[strcspn(shared_data->user_option, "\n")] = 0;
    printf("You selected: %s\n", shared_data->user_option);

    child_process = fork();
    if (child_process == 0) {
        close(pipe_fd[0]);

        if (strcmp(shared_data->user_option, "a") == 0) {
            int deposit_amount;
            printf("Enter amount to add:\n");
            scanf("%d", &deposit_amount);
            if (deposit_amount > 0) {
                shared_data->account_balance += deposit_amount;
                printf("Money added successfully\n");
                printf("Updated balance: %d\n", shared_data->account_balance);
            } else {
                printf("Failed: Invalid amount\n");
            }
        }
        else if (strcmp(shared_data->user_option, "w") == 0) {
            int withdraw_amount;
            printf("Enter amount to withdraw:\n");
            scanf("%d", &withdraw_amount);
            if (withdraw_amount > 0 && withdraw_amount <= shared_data->account_balance) {
                shared_data->account_balance -= withdraw_amount;
                printf("Money withdrawn successfully\n");
                printf("Updated balance: %d\n", shared_data->account_balance);
            } else {
                printf("Failed: Invalid amount\n");
            }
        }
        else if (strcmp(shared_data->user_option, "c") == 0) {
            printf("Current balance: %d\n", shared_data->account_balance);
        }
        else {
            printf("Invalid option\n");
        }

        const char *exit_message = "Thank you for banking with us!\n";
        write(pipe_fd[1], exit_message, strlen(exit_message));
        close(pipe_fd[1]);
        shmdt(shared_data);
        exit(0);
    }
    else {
        close(pipe_fd[1]);
        wait(NULL);
        int read_bytes = read(pipe_fd[0], pipe_buffer, sizeof(pipe_buffer) - 1);
        if (read_bytes > 0) {
            pipe_buffer[read_bytes] = '\0';
            printf("%s", pipe_buffer);
            fflush(stdout);
        }

        shmdt(shared_data);
        shmctl(shared_mem_id, IPC_RMID, NULL);
        close(pipe_fd[0]);
    }

    return 0;
}
