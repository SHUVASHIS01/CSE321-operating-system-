#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USERS 5
#define MAX_RESOURCES 5
#define MAX_NAME_LEN 20

// Permissions
typedef enum {
    READ = 1,
    WRITE = 2,
    EXECUTE = 4
} Permission;

// User and Resource Definitions
typedef struct {
    char name[MAX_NAME_LEN];
} User;

typedef struct {
    char name[MAX_NAME_LEN];
} Resource;

// ACL Entry
typedef struct {
    char username[MAX_NAME_LEN];
    int permissions;
} ACLEntry;

typedef struct {
    Resource resource;
    ACLEntry entries[MAX_USERS];
    int entryCount;
} ACLControlledResource;

// Capability Entry
typedef struct {
    char resourceName[MAX_NAME_LEN];
    int permissions;
} Capability;

typedef struct {
    char username[MAX_NAME_LEN];
    Capability capabilities[MAX_RESOURCES];
    int capCount;
} CapabilityUser;

// Utility Functions
int hasPermission(int userPerm, int requiredPerm) {
    return (userPerm & requiredPerm) == requiredPerm;
}

// ACL System
void checkACLAccess(ACLControlledResource *res, const char *userName, int perm) {
    for (int i = 0; i < res->entryCount; i++) {
        if (strcmp(res->entries[i].username, userName) == 0) {
            if (hasPermission(res->entries[i].permissions, perm)) {
                printf("ACL Check: User %s requests %s on %s: Access GRANTED\n",
                       userName,
                       (perm == READ ? "READ" : perm == WRITE ? "WRITE" : "EXECUTE"),
                       res->resource.name);
            } else {
                printf("ACL Check: User %s requests %s on %s: Access DENIED\n",
                       userName,
                       (perm == READ ? "READ" : perm == WRITE ? "WRITE" : "EXECUTE"),
                       res->resource.name);
            }
            return;
        }
    }
    printf("ACL Check: User %s requests %s on %s: Access DENIED\n",
           userName,
           (perm == READ ? "READ" : perm == WRITE ? "WRITE" : "EXECUTE"),
           res->resource.name);
}

// Capability System
void checkCapabilityAccess(CapabilityUser *user, const char *resourceName, int perm) {
    for (int i = 0; i < user->capCount; i++) {
        if (strcmp(user->capabilities[i].resourceName, resourceName) == 0) {
            if (hasPermission(user->capabilities[i].permissions, perm)) {
                printf("Capability Check: User %s requests %s on %s: Access GRANTED\n",
                       user->username,
                       (perm == READ ? "READ" : perm == WRITE ? "WRITE" : "EXECUTE"),
                       resourceName);
            } else {
                printf("Capability Check: User %s requests %s on %s: Access DENIED\n",
                       user->username,
                       (perm == READ ? "READ" : perm == WRITE ? "WRITE" : "EXECUTE"),
                       resourceName);
            }
            return;
        }
    }
    printf("Capability Check: User %s requests %s on %s: Access DENIED\n",
           user->username,
           (perm == READ ? "READ" : perm == WRITE ? "WRITE" : "EXECUTE"),
           resourceName);
}

int main() {
    // Users
    User users[MAX_USERS] = {{"Alice"}, {"Bob"}, {"Charlie"}, {"Dave"}, {"Eve"}};
    // Resources
    Resource resources[MAX_RESOURCES] = {{"File1"}, {"File2"}, {"File3"}, {"File4"}, {"File5"}};

    // ACL Setup
    ACLControlledResource aclResources[MAX_RESOURCES];
    for (int i = 0; i < MAX_RESOURCES; i++) {
        aclResources[i].resource = resources[i];
        aclResources[i].entryCount = 0;
    }

    // File1 ACL
    strcpy(aclResources[0].entries[0].username, "Alice");
    aclResources[0].entries[0].permissions = READ | WRITE;
    strcpy(aclResources[0].entries[1].username, "Bob");
    aclResources[0].entries[1].permissions = READ;
    aclResources[0].entryCount = 2;

    // File2 ACL
    strcpy(aclResources[1].entries[0].username, "Charlie");
    aclResources[1].entries[0].permissions = EXECUTE;
    aclResources[1].entryCount = 1;

    // File3 ACL
    strcpy(aclResources[2].entries[0].username, "Bob");
    aclResources[2].entries[0].permissions = READ | EXECUTE;
    aclResources[2].entryCount = 1;

    // File4 ACL
    strcpy(aclResources[3].entries[0].username, "Dave");
    aclResources[3].entries[0].permissions = WRITE | EXECUTE;
    aclResources[3].entryCount = 1;

    // File5 ACL
    strcpy(aclResources[4].entries[0].username, "Eve");
    aclResources[4].entries[0].permissions = READ | WRITE | EXECUTE;
    aclResources[4].entryCount = 1;

    // Capabilities
    CapabilityUser capUsers[MAX_USERS];
    for (int i = 0; i < MAX_USERS; i++) {
        strcpy(capUsers[i].username, users[i].name);
        capUsers[i].capCount = 0;
    }

    // Alice
    strcpy(capUsers[0].capabilities[0].resourceName, "File1");
    capUsers[0].capabilities[0].permissions = READ | WRITE;
    capUsers[0].capCount = 1;

    // Bob
    strcpy(capUsers[1].capabilities[0].resourceName, "File1");
    capUsers[1].capabilities[0].permissions = READ;
    strcpy(capUsers[1].capabilities[1].resourceName, "File3");
    capUsers[1].capabilities[1].permissions = READ | EXECUTE;
    capUsers[1].capCount = 2;

    // Charlie
    strcpy(capUsers[2].capabilities[0].resourceName, "File2");
    capUsers[2].capabilities[0].permissions = EXECUTE;
    capUsers[2].capCount = 1;

    // Dave
    strcpy(capUsers[3].capabilities[0].resourceName, "File4");
    capUsers[3].capabilities[0].permissions = WRITE | EXECUTE;
    capUsers[3].capCount = 1;

    // Eve
    strcpy(capUsers[4].capabilities[0].resourceName, "File5");
    capUsers[4].capabilities[0].permissions = READ | WRITE | EXECUTE;
    capUsers[4].capCount = 1;

    // Test ACL
    checkACLAccess(&aclResources[0], "Alice", READ);
    checkACLAccess(&aclResources[0], "Bob", WRITE);
    checkACLAccess(&aclResources[0], "Charlie", READ);
    checkACLAccess(&aclResources[1], "Charlie", EXECUTE);
    checkACLAccess(&aclResources[2], "Bob", READ);
    checkACLAccess(&aclResources[3], "Dave", EXECUTE);
    checkACLAccess(&aclResources[4], "Eve", WRITE);
    checkACLAccess(&aclResources[2], "Alice", EXECUTE);

    // Test Capability
    checkCapabilityAccess(&capUsers[0], "File1", WRITE);
    checkCapabilityAccess(&capUsers[1], "File1", WRITE);
    checkCapabilityAccess(&capUsers[2], "File2", READ);
    checkCapabilityAccess(&capUsers[2], "File2", EXECUTE);
    checkCapabilityAccess(&capUsers[1], "File3", EXECUTE);
    checkCapabilityAccess(&capUsers[3], "File4", WRITE);
    checkCapabilityAccess(&capUsers[4], "File5", READ);
    checkCapabilityAccess(&capUsers[0], "File1", EXECUTE);
    checkCapabilityAccess(&capUsers[1], "File2", READ);

    return 0;
}

