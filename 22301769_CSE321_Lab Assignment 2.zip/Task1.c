#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int seqLength;  
int lookupCount; 
int *fibArray;    
int *lookupIndices;
int *lookupResults;
void *makeFibonacci(void *param);
void *findFibonacci(void *param);

int main() {
    pthread_t t1, t2;
    int terms;
    printf("Enter the term of fibonacci sequence: ");
    scanf("%d", &terms);
    seqLength = terms;
    pthread_create(&t1, NULL, makeFibonacci, &terms);
    pthread_join(t1, NULL);
    for (int j = 0; j <= seqLength; j++) {
        printf("Fib[%d] = %d\n", j, fibArray[j]);
    }

    printf("How many numbers you want to lookup?: ");
    scanf("%d", &lookupCount);
    lookupIndices = (int *)malloc(lookupCount * sizeof(int));
    lookupResults = (int *)malloc(lookupCount * sizeof(int));
    for (int k = 0; k < lookupCount; k++) {
        printf("Enter lookup %d: ", k + 1);
        scanf("%d", &lookupIndices[k]);
    }
    pthread_create(&t2, NULL, findFibonacci, lookupIndices);
    pthread_join(t2, NULL);

    for (int m = 0; m < lookupCount; m++) {
        printf("Result of lookup #%d = %d\n", m + 1, lookupResults[m]);
    }
    return 0;
}

void *makeFibonacci(void *param) {
    int limit = *(int *)param;
    fibArray = (int *)malloc((limit + 1) * sizeof(int));
    if (!fibArray) {
        perror("malloc");
        pthread_exit(NULL);
    }
    fibArray[0] = 0;
    if (limit >= 1) fibArray[1] = 1;
    for (int i = 2; i <= limit; i++) {
        fibArray[i] = fibArray[i - 1] + fibArray[i - 2];
    }
    pthread_exit(NULL);
}

void *findFibonacci(void *param) {
    int *indices = (int *)param;
    for (int i = 0; i < lookupCount; i++) {
        int idx = indices[i];
        if (idx >= 0 && idx <= seqLength) {
            lookupResults[i] = fibArray[idx];
        } else {
            lookupResults[i] = -1;
        }
    }
    pthread_exit(NULL);
}
