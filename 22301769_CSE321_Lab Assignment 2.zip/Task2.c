#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define TOTAL_STUDENTS 10
#define LOBBY_SEATS 3

// Counters
int waitingStudents = 0;      
int finishedStudents = 0;     

pthread_mutex_t lock;         // Protects counters
sem_t studentSignal;          // Student ready
sem_t tutorSignal;            // Tutor ready

void *studentLife(void *arg);
void *tutorLife(void *arg);

int main() {
    pthread_t t1;                       // Tutor thread
    pthread_t t2[TOTAL_STUDENTS];       // Student threads

    pthread_mutex_init(&lock, NULL);
    sem_init(&studentSignal, 0, 0);
    sem_init(&tutorSignal, 0, 0);

    // Start tutor
    pthread_create(&t1, NULL, tutorLife, NULL);

    // Start students (arrive randomly)
    for (int i = 0; i < TOTAL_STUDENTS; i++) {
        int *id = malloc(sizeof(int));
        *id = i;
        pthread_create(&t2[i], NULL, studentLife, id);
        sleep(rand() % 2);
    }

    // Wait for all students
    for (int i = 0; i < TOTAL_STUDENTS; i++) {
        pthread_join(t2[i], NULL);
    }

    // Tutor finishes after serving everyone
    pthread_join(t1, NULL);

    // Cleanup
    sem_destroy(&studentSignal);
    sem_destroy(&tutorSignal);
    pthread_mutex_destroy(&lock);

    return 0;
}

void *studentLife(void *arg) {
    int id = *(int *)arg;
    free(arg);

    printf("Student %d arrived for help\n", id);

    pthread_mutex_lock(&lock);
    if (waitingStudents < LOBBY_SEATS) {
        waitingStudents++;
        printf("Seats filled: %d\n", waitingStudents);
        pthread_mutex_unlock(&lock);

        sem_post(&studentSignal);  // Notify tutor
        sem_wait(&tutorSignal);    // Wait turn

        printf("Student %d got help and left\n", id);

        pthread_mutex_lock(&lock);
        finishedStudents++;
        waitingStudents--;
        printf("Total students served: %d\n", finishedStudents);
        pthread_mutex_unlock(&lock);
    } else {
        pthread_mutex_unlock(&lock);
        printf("No seat left. Student %d went away\n", id);
    }

    pthread_exit(NULL);
}

void *tutorLife(void *arg) {
    while (1) {
        sem_wait(&studentSignal);  // Wait for a student

        pthread_mutex_lock(&lock);
        if (finishedStudents >= TOTAL_STUDENTS) {
            pthread_mutex_unlock(&lock);
            break;
        }
        printf("Tutor is consulting a student...\n");
        pthread_mutex_unlock(&lock);

        sem_post(&tutorSignal);   // Let a student in
        sleep(1);                 // Simulate consultation time
    }
    pthread_exit(NULL);
}
