#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/wait.h>

struct msg_queue {
    long int msg_type;
    char msg_data[6];
};

int main() {
    int msg_queue_id = msgget((key_t)7890, 0666 | IPC_CREAT);
    if (msg_queue_id == -1) {
        perror("msgget failed");
        exit(0);
    }

    struct msg_queue login_message;
    char workspace_name[100];
    long type_login_to_otp = 1;
    long type_otp_to_login = 2;
    long type_otp_to_mail = 3;
    long type_mail_to_login = 4;

    printf("Please enter the workspace name:\n");
    scanf("%s", workspace_name);

    if (strcmp(workspace_name, "cse321") != 0) {
        printf("Invalid workspace name\n");
        msgctl(msg_queue_id, IPC_RMID, NULL);
        exit(0);
    }

    login_message.msg_type = type_login_to_otp;
    strncpy(login_message.msg_data, workspace_name, sizeof(login_message.msg_data));
    msgsnd(msg_queue_id, &login_message, sizeof(login_message.msg_data), 0);
    printf("Workspace name sent to OTP generator from log in: %s\n\n", login_message.msg_data);

    pid_t otp_process_id = fork();
    if (otp_process_id == 0) {
        struct msg_queue otp_message;
        msgrcv(msg_queue_id, &otp_message, sizeof(otp_message.msg_data), type_login_to_otp, 0);
        printf("OTP generator received workspace name from log in: %s\n\n", otp_message.msg_data);

        otp_message.msg_type = type_otp_to_login;
        snprintf(otp_message.msg_data, sizeof(otp_message.msg_data), "%d", getpid());
        msgsnd(msg_queue_id, &otp_message, sizeof(otp_message.msg_data), 0);
        printf("OTP sent to log in from OTP generator: %s\n", otp_message.msg_data);

        otp_message.msg_type = type_otp_to_mail;
        msgsnd(msg_queue_id, &otp_message, sizeof(otp_message.msg_data), 0);
        printf("OTP sent to mail from OTP generator: %s\n", otp_message.msg_data);
        exit(0);
    }

    wait(NULL);

    pid_t mail_process_id = fork();
    if (mail_process_id == 0) {
        struct msg_queue mail_message;
        msgrcv(msg_queue_id, &mail_message, sizeof(mail_message.msg_data), type_otp_to_mail, 0);
        printf("Mail received OTP from OTP generator: %s\n", mail_message.msg_data);

        mail_message.msg_type = type_mail_to_login;
        msgsnd(msg_queue_id, &mail_message, sizeof(mail_message.msg_data), 0);
        printf("OTP sent to log in from mail: %s\n", mail_message.msg_data);
        exit(0);
    }

    wait(NULL);

    struct msg_queue otp_received_msg, mail_received_msg;
    msgrcv(msg_queue_id, &otp_received_msg, sizeof(otp_received_msg.msg_data), type_otp_to_login, 0);
    printf("Log in received OTP from OTP generator: %s\n", otp_received_msg.msg_data);

    msgrcv(msg_queue_id, &mail_received_msg, sizeof(mail_received_msg.msg_data), type_mail_to_login, 0);
    printf("Log in received OTP from mail: %s\n", mail_received_msg.msg_data);

    if (strcmp(otp_received_msg.msg_data, mail_received_msg.msg_data) == 0)
        printf("OTP Verified\n");
    else
        printf("OTP Incorrect\n");

    msgctl(msg_queue_id, IPC_RMID, NULL);
    return 0;
}
